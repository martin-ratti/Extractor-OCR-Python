IMPORTANTE:

Este programa requiere Tesseract OCR para funcionar.
Por favor, copie el contenido de su instalación de Tesseract (normalmente C:\Program Files\Tesseract-OCR) dentro de esta carpeta.

Debe haber un archivo 'tesseract.exe' directamente en esta carpeta:
ExtractorOCR/Tesseract-OCR/tesseract.exe
